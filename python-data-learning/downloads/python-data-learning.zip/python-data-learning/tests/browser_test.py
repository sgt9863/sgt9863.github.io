"""Run with a locally installed Chrome and optional playwright test dependency."""
from pathlib import Path
import json
import hashlib
import os
import tempfile
import zipfile
from playwright.sync_api import sync_playwright, expect

ROOT = Path(__file__).resolve().parents[1]
URL = os.environ.get('BROWSER_TEST_URL', 'http://localhost:5186/site/')
course = json.loads((ROOT / 'content/course.json').read_text())
all_lessons = [lesson for chapter in course['chapters'] for lesson in chapter['lessons']]
indexes = {
    'pandas': {'chapter': 'pandas', 'heading': '表を読む・整える・集計する'},
    'numpy': {'chapter': 'NumPy', 'heading': '配列を使って、数値を計算する'},
    'matplotlib': {'chapter': 'Matplotlib', 'heading': '図の種類を選び、軸や配置を整える'},
    'seaborn': {'chapter': 'seaborn', 'heading': 'DataFrameから、分布と関係を描く'},
    'scikit-learn': {'chapter': 'scikit-learn', 'heading': '前処理から予測・評価まで、一連の手順を学ぶ'},
}
for index in indexes.values():
    index['lessons'] = next(c['lessons'] for c in course['chapters'] if c['title'] == index['chapter'])


def validate_rendered_fields(payload, source):
    """Reject malformed authored metadata before it reaches array-based rendering."""
    ids = []
    for chapter in payload['chapters']:
        assert isinstance(chapter['lessons'], list), (source, chapter['title'], 'lessons')
        for lesson in chapter['lessons']:
            lid = lesson['id']
            ids.append(lid)
            for field in ['goals', 'mistakes', 'reflection']:
                value = lesson[field]
                assert isinstance(value, list) and all(isinstance(item, str) for item in value), (source, lid, field)
            for field in ['apis', 'try_it']:
                if field in lesson:
                    value = lesson[field]
                    assert isinstance(value, list) and all(isinstance(item, str) for item in value), (source, lid, field)
            assert isinstance(lesson['minutes'], int) and 20 <= lesson['minutes'] <= 40, (source, lid, 'minutes')
            assert isinstance(lesson['exercise']['prompt'], str), (source, lid, 'prompt')
            hints = lesson['exercise']['hints']
            assert isinstance(hints, list) and all(isinstance(hint, str) for hint in hints), (source, lid, 'hints')
    assert len(ids) == len(set(ids)), (source, 'duplicate lesson IDs')
    return ids


source_ids = validate_rendered_fields(course, 'content/course.json')


def full_width(text):
    return ''.join(chr(ord(char) + 0xFEE0) if '!' <= char <= '~' else char for char in text)


with sync_playwright() as p:
    browser = p.chromium.launch(
        executable_path='/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
        headless=True,
    )
    context = browser.new_context(
        viewport={'width': 1440, 'height': 1000},
        permissions=['clipboard-read', 'clipboard-write'],
        accept_downloads=True,
    )
    page = context.new_page()
    errors = []
    page.on('pageerror', lambda error: errors.append(str(error)))
    page.on('console', lambda message: errors.append(f'console.error: {message.text}') if message.type == 'error' else None)
    # The browser's automatic icon request is unrelated to the course assets.
    page.route('**/favicon.ico', lambda route: route.fulfill(status=204))
    assert page.goto(URL).status == 200
    page.locator('h1').wait_for()
    served_course = page.evaluate('window.COURSE')
    assert validate_rendered_fields(served_course, URL + 'course.js') == source_ids
    page.keyboard.press('Tab')
    expect(page.locator('.skip')).to_be_focused()
    page.keyboard.press('Enter')
    expect(page.locator('#main')).to_be_focused()
    expect(page.locator('h1')).to_have_text('測定データから、Pythonを学ぼう。')
    page.screenshot(path='/tmp/hplc-home-desktop.png', full_page=True)

    for route, index in indexes.items():
        items = index['lessons']
        first, second = items[:2]
        page.goto(URL + '#home')
        page.locator(f'.course-list a[href="#{route}"]').click()
        expect(page.locator('h1')).to_have_text(index['heading'])
        expect(page.locator('h1')).to_be_in_viewport()
        expect(page).to_have_title(f'{index["chapter"]}の全体像・機能索引 — Pythonデータ分析')
        results = page.locator(f'#{route}-results')
        expect(results.locator('article')).to_have_count(len(items))
        assert page.locator('#toc a[aria-current="page"]').get_attribute('href') == '#' + route
        page.screenshot(path=f'/tmp/hplc-{route}-index-desktop.png', full_page=False)
        search = page.locator(f'#{route}-search')
        search.fill(second['id'].lower())
        expect(results.locator('article')).to_have_count(1)
        expect(results.locator('h3 a')).to_have_attribute('href', '#' + second['id'])
        expect(page.locator('#search-count')).to_have_text('1件のレッスンが見つかりました')
        # Every query term must match; case and full-width ASCII are normalized.
        search.fill(full_width(second['id']))
        expect(results.locator('article')).to_have_count(1)
        search.fill(full_width(second['id']) + ' no-such-lesson')
        expect(results.locator('article')).to_have_count(0)
        expect(page.locator('.no-results')).to_be_visible()
        page.locator('#clear-search').click()
        expect(search).to_be_focused()
        expect(results.locator('article')).to_have_count(len(items))
        api_lesson = next((lesson for lesson in items if lesson.get('apis')), None)
        if api_lesson:
            search.fill(api_lesson['apis'][0].upper())
            expect(results.locator(f'a[href="#{api_lesson["id"]}"]')).to_be_visible()
        if route == 'scikit-learn':
            for query in ['Pipeline', 'cross_validate', 'PCA']:
                expected = [lesson for lesson in items if any(query.casefold() in api.casefold() for api in lesson.get('apis', []))]
                assert expected, ('Missing documented scikit-learn API', query)
                search.fill(query)
                for lesson in expected:
                    expect(results.locator(f'a[href="#{lesson["id"]}"]')).to_be_visible()
        search.fill(second['id'])
        page.keyboard.press('Tab')
        expect(page.locator('#clear-search')).to_be_focused()
        assert page.locator('#clear-search').evaluate("el=>getComputedStyle(el).outlineStyle!=='none'")
        page.keyboard.press('Tab')
        expect(results.locator('h3 a')).to_be_focused()
        page.keyboard.press('Enter')
        expect(page).to_have_url(URL + '#' + second['id'])
        page.locator(f'#toc a[href="#{first["id"]}"]').click()
        expect(page.locator('h1')).to_have_text(first['title'])
        expect(page.locator('#toc a[aria-current="page"]')).to_have_count(1)
        page.locator('.page-toc button').filter(has_text='演習 ' + first['id']).click()
        expect(page).to_have_url(URL + '#' + first['id'])
        assert page.evaluate(
            '(id)=>document.activeElement.tagName==="H2" && document.activeElement.textContent==="演習 "+id',
            first['id'],
        )
        page.locator('button[data-copy]').nth(1).click()
        assert page.evaluate('navigator.clipboard.readText()') == first['example']
        page.locator('#complete').check()
        page.reload()
        expect(page.locator('#complete')).to_be_checked()
        assert '✓ 完了' in page.locator('#toc a[aria-current="page"]').inner_text()
        page.locator('.back-to-chapter a').click()
        expect(page).to_have_url(URL + '#' + route)
        expect(page.locator(f'#{route}-results article').filter(has=page.locator(f'a[href="#{first["id"]}"]')).locator('.done-label')).to_have_text('✓ 完了')
        page.locator(f'#{route}-results a[href="#{first["id"]}"]').click()
        page.locator('#complete').uncheck()
        page.locator('.bottom-nav a').last.click()
        expect(page).to_have_url(URL + '#' + second['id'])
        page.locator('.bottom-nav a').first.click()
        expect(page).to_have_url(URL + '#' + first['id'])
        page.screenshot(path=f'/tmp/hplc-{route}-lesson-desktop.png', full_page=True)

    for lesson in all_lessons:
        page.goto(URL + '#' + lesson['id'])
        expect(page.locator('h1')).to_have_text(lesson['title'])
        assert lesson['exercise']['prompt'] in page.locator('main').inner_text()
        assert page.locator('.output').inner_html()
        current = page.locator('#toc a[aria-current="page"]')
        expect(current).to_be_visible()
        assert current.evaluate('el=>{const r=el.getBoundingClientRect(),n=el.closest("nav").getBoundingClientRect();return r.top>=n.top-1 && r.bottom<=n.bottom+1;}')
        if lesson.get('scenario'):
            assert lesson['scenario'] in page.locator('.scenario').inner_text()
        if lesson.get('try_it'):
            expect(page.locator('.try-it li')).to_have_count(len(lesson['try_it']))
        page.wait_for_function('Array.from(document.querySelectorAll("main img")).every(i=>i.complete && i.naturalWidth>0)')

    # Motion starts only on request, can be stopped, and respects preference changes.
    if any(lesson['id'] == 'MPL-24' for lesson in all_lessons):
        page.emulate_media(reduced_motion='reduce')
        # Let the preference change event settle before the user requests playback.
        page.evaluate('() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)))')
        page.goto(URL + '#MPL-24')
        expect(page.locator('h1')).to_have_text(next(l['title'] for l in all_lessons if l['id']=='MPL-24'))
        animation = page.locator('details.animation-demo')
        expect(animation).to_have_count(1)
        expect(animation).not_to_have_attribute('open', '')
        expect(animation.locator('.animation-content img')).to_have_count(0)
        expect(animation.locator('summary')).to_have_text('アニメーションを再生')
        animation.locator('summary').focus()
        expect(animation.locator('summary')).to_be_focused()
        page.keyboard.press('Enter')
        expect(animation).to_have_attribute('open', '')
        expect(animation.locator('.animation-content img')).to_have_count(1)
        expect(animation.locator('summary')).to_have_text('アニメーションを停止')
        page.wait_for_function('document.querySelector(".animation-content img")?.naturalWidth > 0')
        page.keyboard.press('Enter')
        expect(animation).not_to_have_attribute('open', '')
        expect(animation.locator('.animation-content img')).to_have_count(0)
        page.emulate_media(reduced_motion='no-preference')
        animation.locator('summary').click()
        expect(animation.locator('.animation-content img')).to_have_count(1)
        page.emulate_media(reduced_motion='reduce')
        expect(animation).not_to_have_attribute('open', '')
        expect(animation.locator('.animation-content img')).to_have_count(0)
        page.emulate_media(reduced_motion='no-preference')

    page.goto(URL + '#toString')
    expect(page.locator('h1')).to_have_text('ページが見つかりません')

    # Save actual browser downloads and inspect the delivered files.
    downloads = Path(tempfile.mkdtemp(prefix='hplc-browser-download-'))
    page.goto(URL + '#downloads')
    expect(page.locator('a[download][href$="solutions.ipynb"]')).not_to_be_visible()
    for filename in ['python-data-learning.zip', 'exercises.ipynb']:
        with page.expect_download() as download:
            page.locator(f'a[download][href$="{filename}"]').click()
        download.value.save_as(downloads / filename)
    page.locator('main summary').click()
    with page.expect_download() as download:
        page.locator('a[download][href$="solutions.ipynb"]').click()
    download.value.save_as(downloads / 'solutions.ipynb')
    for filename, expected in [('exercises.ipynb', ROOT/'exercises.ipynb'), ('solutions.ipynb', ROOT/'solutions.ipynb'), ('python-data-learning.zip', ROOT/'downloads/python-data-learning.zip')]:
        assert hashlib.sha256((downloads/filename).read_bytes()).digest() == hashlib.sha256(expected.read_bytes()).digest(), filename
    for name in ['exercises', 'solutions']:
        assert json.loads((downloads / f'{name}.ipynb').read_text())['nbformat'] == 4
    with zipfile.ZipFile(downloads / 'python-data-learning.zip') as archive:
        assert len([name for name in archive.namelist() if name.endswith('.ipynb')]) == 2
        assert 'python-data-learning/data/hplc.csv' in archive.namelist()
        archive.extractall(downloads)
    print('DOWNLOAD_DIR=' + str(downloads), flush=True)

    # Check narrow layout, menu accessibility and all pages without body overflow.
    page.set_viewport_size({'width': 390, 'height': 844})
    for route, index in indexes.items():
        items = index['lessons']
        page.goto(URL + '#home')
        expect(page.locator('#toc')).not_to_be_visible()
        page.locator('#menu').click()
        expect(page.locator('#menu')).to_have_attribute('aria-expanded', 'true')
        page.locator(f'#toc a[href="#{items[0]["id"]}"]').click()
        expect(page.locator('#toc')).not_to_be_visible()
        expect(page.locator('.page-toc')).to_be_visible()
        page.locator('.back-to-chapter a').click()
        expect(page.locator(f'#{route}-search')).to_be_visible()
        assert page.evaluate('document.documentElement.scrollWidth <= window.innerWidth')
        page.screenshot(path=f'/tmp/hplc-{route}-index-mobile.png', full_page=False)
        page.locator(f'#{route}-search').fill(items[-1]['id'])
        expect(page.locator(f'#{route}-results article')).to_have_count(1)
        page.locator(f'#{route}-results h3 a').click()
        expect(page).to_have_url(URL + '#' + items[-1]['id'])
        page.locator('#menu').click()
        current = page.locator('#toc a[aria-current="page"]')
        expect(current).to_be_visible()
        page.wait_for_function('''() => {
          const el=document.querySelector('#toc a[aria-current="page"]');
          if(!el)return false;
          const r=el.getBoundingClientRect(),n=el.closest('nav').getBoundingClientRect();
          return r.top>=n.top && r.bottom<=n.bottom;
        }''')
        nav_metrics = page.locator('#toc').evaluate('el=>({height:el.clientHeight,scrollHeight:el.scrollHeight,scrollTop:el.scrollTop})')
        assert nav_metrics['height'] <= 500 and nav_metrics['scrollHeight'] > nav_metrics['height']
        assert current.evaluate('el=>{const r=el.getBoundingClientRect(),n=el.closest("nav").getBoundingClientRect();return r.top>=n.top && r.bottom<=n.bottom;}')
        current.click()
        expect(page.locator('#menu')).to_have_attribute('aria-expanded', 'false')
        expect(page.locator('#main')).to_be_focused()
        page.locator('#menu').click()
        page.locator('#menu').click()
    for lesson in all_lessons:
        page.goto(URL + '#' + lesson['id'])
        expect(page.locator('h1')).to_have_text(lesson['title'])
        assert page.evaluate('document.documentElement.scrollWidth <= window.innerWidth'), lesson['id']
    page.goto(URL + '#ML-01')
    expect(page.locator('h1')).to_have_text(indexes['scikit-learn']['lessons'][0]['title'])
    page.screenshot(path='/tmp/hplc-scikit-learn-lesson-mobile.png', full_page=False)
    assert not errors, errors
    print(
        f'PASS desktop/mobile, {len(all_lessons)} pages, '
        + '/'.join(index['chapter'] for index in indexes.values()) + ' index/search, keyboard navigation, '
        'page contents, clipboard, persistence, previous/next, images, animation controls when present, '
        '3 downloads, source/delivered metadata schema, no JavaScript or console errors',
        flush=True,
    )
    browser.close()
