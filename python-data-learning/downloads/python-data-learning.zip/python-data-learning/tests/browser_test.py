"""Run with a locally installed Chrome and optional playwright test dependency."""
from pathlib import Path
import json, tempfile, zipfile, os
from playwright.sync_api import sync_playwright, expect
ROOT=Path(__file__).resolve().parents[1]
URL=os.environ.get('BROWSER_TEST_URL','http://localhost:5186/site/')
course=json.loads((ROOT/'content/course.json').read_text())
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless=True)
    context=browser.new_context(viewport={'width':1440,'height':1000},permissions=['clipboard-read','clipboard-write'],accept_downloads=True)
    page=context.new_page(); errors=[]
    page.on('pageerror',lambda e:errors.append(str(e)))
    assert page.goto(URL).status==200
    page.locator('h1').wait_for()
    page.keyboard.press('Tab')
    assert page.locator('.skip').evaluate('(el)=>el===document.activeElement')
    page.keyboard.press('Enter')
    assert page.locator('#main').evaluate('(el)=>el===document.activeElement')
    assert page.locator('h1').inner_text()=='測定データから、\nPythonを学ぼう。'
    page.screenshot(path='/tmp/hplc-home-desktop.png',full_page=True)
    page.locator('#toc a[href="#PD-01"]').click()
    expect(page.locator('h1')).to_contain_text('CSVを開き')
    assert page.locator('#toc a[aria-current="page"]').count()==1
    first_example=page.locator('button[data-copy]').nth(1)
    first_example.click()
    assert 'read_csv' in page.evaluate('navigator.clipboard.readText()')
    page.locator('#complete').check()
    page.reload()
    assert page.locator('#complete').is_checked()
    assert '✓ 完了' in page.locator('#toc a[aria-current="page"]').inner_text()
    page.locator('#complete').uncheck()
    page.locator('.bottom-nav a').last.click()
    expect(page).to_have_url(URL+'#PD-02')
    page.locator('.bottom-nav a').first.click()
    expect(page).to_have_url(URL+'#PD-01')
    page.screenshot(path='/tmp/hplc-lesson-desktop.png',full_page=True)
    for ch in course['chapters']:
        for l in ch['lessons']:
            page.goto(URL+'#'+l['id'])
            expect(page.locator('h1')).to_have_text(l['title'])
            assert l['exercise']['prompt'] in page.locator('main').inner_text()
            assert page.locator('.output').inner_html()
            assert page.wait_for_function('Array.from(document.querySelectorAll("main img")).every(i=>i.complete && i.naturalWidth>0)')
    # Save actual browser downloads and inspect the delivered files.
    downloads=Path(tempfile.mkdtemp(prefix='hplc-browser-download-'))
    page.goto(URL+'#downloads')
    assert not page.locator('a[download][href$="solutions.ipynb"]').is_visible()
    for filename,href in [('python-data-learning.zip','../downloads/python-data-learning.zip'),('exercises.ipynb','../exercises.ipynb')]:
        with page.expect_download() as d:page.locator(f'a[download][href$="{filename}"]').click()
        d.value.save_as(downloads/filename)
    page.locator('main summary').click()
    with page.expect_download() as d:page.locator('a[download][href$="solutions.ipynb"]').click()
    d.value.save_as(downloads/'solutions.ipynb')
    for name in ['exercises','solutions']:assert json.loads((downloads/f'{name}.ipynb').read_text())['nbformat']==4
    with zipfile.ZipFile(downloads/'python-data-learning.zip') as z:
        assert len([n for n in z.namelist() if n.endswith('.ipynb')])==2
        assert 'python-data-learning/data/hplc.csv' in z.namelist()
        z.extractall(downloads)
    print('DOWNLOAD_DIR='+str(downloads),flush=True)
    # Check narrow layout, menu accessibility and all pages without body overflow.
    page.set_viewport_size({'width':390,'height':844})
    page.goto(URL+'#home')
    expect(page.locator('#toc')).not_to_be_visible()
    page.locator('#menu').click()
    assert page.locator('#menu').get_attribute('aria-expanded')=='true'
    page.locator('#toc a[href="#PD-01"]').click()
    expect(page.locator('#toc')).not_to_be_visible()
    for l in [l for c in course['chapters'] for l in c['lessons']]:
        page.goto(URL+'#'+l['id'])
        expect(page.locator('h1')).to_have_text(l['title'])
        assert page.evaluate('document.documentElement.scrollWidth <= window.innerWidth'),l['id']
    page.goto(URL+'#PD-01')
    expect(page.locator('h1')).to_contain_text('CSVを開き')
    page.screenshot(path='/tmp/hplc-lesson-mobile.png',full_page=False)
    assert not errors,errors
    print('PASS desktop/mobile, 24 pages, keyboard skip, clipboard, persistence, previous/next, images, 3 downloads, no JavaScript errors',flush=True)
    browser.close()
