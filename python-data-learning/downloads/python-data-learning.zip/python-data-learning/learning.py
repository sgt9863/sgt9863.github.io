"""Small offline helpers shared by the two notebooks."""
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parent

def setup_plotting():
    import matplotlib as mpl
    from matplotlib import font_manager
    font = ROOT / 'assets' / 'NotoSansJP.ttf'
    if not font.exists():
        raise FileNotFoundError('assets/NotoSansJP.ttf がありません。教材ZIPをすべて展開してください。')
    font_manager.fontManager.addfont(str(font))
    mpl.rcParams['font.family'] = font_manager.FontProperties(fname=str(font)).get_name()
    mpl.rcParams['axes.unicode_minus'] = False
    mpl.rcParams['figure.figsize'] = (7, 4)
    mpl.rcParams['figure.dpi'] = 100


def check_answer(exercise_id, answer):
    if answer is None:
        print(f'{exercise_id}：まだ未回答です。TODOセルを編集して実行してください。ほかの章へ進んでも構いません。')
        return False
    import numpy as np
    import pandas as pd
    import matplotlib.pyplot as plt
    import seaborn as sns
    from IPython.display import display
    course = json.loads((ROOT / 'content' / 'course.json').read_text())
    for chapter in course['chapters']:
        for lesson in chapter['lessons']:
            if lesson['id'] == exercise_id:
                ex = lesson['exercise']
                scope = {'np': np, 'pd': pd, 'plt': plt, 'sns': sns, 'Path': Path, 'display': display,
                         'df': pd.read_csv(ROOT/'data/hplc.csv'),
                         'analytes': pd.read_csv(ROOT/'data/analytes.csv'), ex['variable']: answer}
                # Only local authored rubric expressions are evaluated, never user text.
                try:
                    passed = bool(eval(ex['check'], scope))
                except Exception as err:
                    print(f'{exercise_id}：型や列名を確認してください（{type(err).__name__}）。問題文の達成条件と比較しましょう。')
                    return False
                print(f'{exercise_id}：' + ('自動確認の条件を満たしました。解釈・グラフは下の観点でも確認しましょう。' if passed else 'まだ条件を満たしていません。問題文の形状・単位・列名を見直しましょう。'))
                return passed
    raise KeyError(exercise_id)
