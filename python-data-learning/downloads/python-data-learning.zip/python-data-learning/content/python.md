# 必要なところでPythonを復習する

初めからすべて暗記する必要はありません。まずPD-01でCSVを開き、使う構文が分からなくなったときに戻ってください。以下は小さな独立した例です。

## 名前を付ける・比較する

`=`は右側の値に名前を付けます。`==`は同じ値かを調べます。`import pandas as pd`はライブラリ（便利な機能の集まり）を読み込み、短い名前`pd`で使う指定です。

```python
sample = "ショウキョウ"
print(sample == "ショウキョウ")  # True：条件に合う
```

DataFrameの列全体と比較すると、行ごとにTrue/Falseが並びます。`df[df["herb"] == "ショウキョウ"]`は、その条件がTrueの行を選びます。

## リストで、順序のある複数の値をまとめる

角括弧`[]`で値を並べます。位置は0から数えます。

```python
columns = ["temperature", "flow", "acn"]
print(columns[0])  # temperature
print(columns[1:3])  # flow と acn。終点3は含まない
```

`df[columns]`は複数列を選びます。`df["flow"]`がSeries、`df[["flow"]]`が1列のDataFrameになる違いも確認しましょう。

## 辞書で、名前と値を対応させる

波括弧`{}`の中に`キー: 値`を並べます。複数の結果や、列ごとの設定をまとめるときに使います。

```python
units = {"flow": "mL/min", "temperature": "℃"}
print(units["flow"])  # mL/min
```

## 条件分岐で、処理を選ぶ

`if`の条件がTrueなら字下げした部分を実行します。`else`はそれ以外の場合です。`None`は「まだ値がない」ことを表し、この教材の未回答にも使います。

```python
answer = None
if answer is None:
    print("まだ未回答です")
else:
    print("回答を確認しましょう")
```

DataFrameの列全体にPythonの`and`は使えません。複数条件は`(df["flow"] > 0.6) & (df["acn"] < 40)`のように、括弧と`&`を使います。

## 繰り返しで、同じ処理を複数回行う

`for`はリストなどから値を一つずつ取り出します。グラフの軸をまとめて整えるときに便利です。

```python
for column in ["flow", "acn"]:
    print(column)
```

インデント（行頭の空白）で処理のまとまりを示します。通常は半角空白4つにそろえます。

## 関数で、処理に名前を付ける

`def`で関数を定義し、丸括弧で値（引数）を渡します。`return`は計算した値を呼び出し元へ返します。

```python
def minutes_to_seconds(minutes):
    return minutes * 60

print(minutes_to_seconds(2.5))  # 150.0
```

`df.head(5)`のようにデータの後にドットを付けて呼ぶ処理はメソッドです。`head`は先頭を取り出し、`5`が行数の指定です。

## 複数の値を受け取る

`fig, ax = plt.subplots()`は、図全体と描画領域の2つを受け取ります。`X_train, X_test, y_train, y_test = train_test_split(X, y, ...)`も同じ仕組みです。右側が返す個数と、左側の名前の個数を合わせます。

`axis=0`のような指定はキーワード引数です。引数の名前を示すので、数値だけを並べるより意図を読み取りやすくなります。

## エラーの最後の行から確認する

- `NameError`：その名前の変数をまだ作っていない可能性があります。章の準備セルを実行します。
- `KeyError`：列名の大文字・小文字・スペルを`df.columns`で確認します。
- `SyntaxError`：括弧や引用符の閉じ忘れ、全角記号を確認します。
- `IndentationError`：字下げを半角空白4つでそろえます。

直しても分からない場合は、演習ID・変更したセル・エラー全文を記録して質問してください。実業務の秘密情報を貼る必要はありません。
