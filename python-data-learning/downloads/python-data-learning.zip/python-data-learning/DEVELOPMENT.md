# 開発記録

## 2026-10-09：初版制作

- 目的：pandasから始め、NumPy、Matplotlib、seaborn、scikit-learn、総合演習へ進む日本語教材。Notebookは演習・解答の2ファイル。
- 既存の統計サイトとは別のローカル教材とする。HTML/CSS/JavaScriptとPython標準HTTPサーバーを採用し、Node.jsの導入を学習者に要求しない。
- ユーザーは3案からA（左目次＋中央本文の教科書型）を選択。Bの課題先行型、Cの進捗カード中心型は見送った。
- 共通の教材定義からサイトとNotebookを生成。例題の出力は実行結果を取り込み、解答は明示的な閲覧操作を経る。
- 当初は売上CSVを検討したが、ユーザーが仕事に近い題材を希望し、HPLC・生薬分析を選択したため変更。独立した架空測定360件と成分マスタを同梱。機械学習は測定前の情報のみを特徴量にし、分割後にPipeline内で補完・変換を学習する。
- Gemini初稿経路：既存認証のAntigravity CLI。`agy models`で`gemini-3.8-flash-high`を確認。公式 https://ai.google.dev/gemini-api/docs/models/gemini-3.8-flash を照合。モデルを明示して呼ぶ。Codexが設計、検証、修正を担当。
- デザイン参照： https://design.digital.go.jp/dads/ （v2.18.0）、foundations/color/、typography/、spacing/、link-text/、components/button/。確認日2026-10-09。
- 検証はNotebook全セル実行、章単独実行、UI操作、ZIP展開先での再実行を行う予定。公開はしない。

## 2026-10-09：統合・検証・公開準備

- 全24レッスンを共通のcontent/course.jsonへ統合。Notebookは演習183セル・解答207セルの2ファイル。各章を単独実行可能にした。
- Geminiへの一括ファイル作成はCLIのcommand権限で拒否された。権限を変更せずテキスト出力へ切り替えたが、長文一括依頼は5分でタイムアウト。15レッスンの説明部分へ範囲を絞ると受信できた。
- 日本語初稿は比較・構成の素材として利用。Pipelineの保証、決定木の性能、実務適用への過剰な断定は不採用。重複段落を除去し、手順に必要な構文説明をCodexが加筆した。レビュー対象：ML-01〜06・ALL-01〜03。独立レビューの指摘から分割条件と使用する準備変数を明記した。
- 自己確認を改善：未回答・TODO未実行も案内、型不一致を検出。機械学習の数値・分割・補完中央値も照合する。グラフと自由記述の意味は人の確認が必要と明示。
- キーボードの「本文へ移動」がSPAルートと衝突したため、フォーカス移動として処理するよう修正した。
- NumPy 2.2.6でMacの行列積の警告を検出。2.5.3へ更新後、警告なしで全セル実行を確認。警告フィルターで隠していない。
- 初稿生成スクリプトと未採用の生原稿を除去し、content/course.jsonを唯一の教材定義として残す。
- ユーザーがオーケストレーションでの再開を希望。主担当が実行検証、Geminiが独立レビューを担当。Codex並列レビューの一部は利用上限で中断し、未完了分を主担当とGeminiで補った。
- ユーザーがsgt9863.comへの公開を指定。既存のGitHub Pages（main /）を確認。新規パス /python-data-learning/ へ静的サイトと教材を追加し、既存トップに案内を置く方針。DNS・CNAMEを変更する必要はない。
- 公開物に仮想環境や実行ログを含めない。全教材ZIPには生成元・データ・フォント・README・検証手順を含める。個人の実測値・認証情報は使っていない。

- ZIPを実ブラウザで取得して別フォルダへ展開し、新しい仮想環境のPythonで両Notebookを全実行。元のディレクトリへの依存がないことを確認。
- 目視確認でグラフ用可変フォントの既定ウェイト100が細すぎると判明。Regular 400へ固定し、サイト用は掲載文字のみのサブセットにした。フォントライセンスを同梱。

## 公開

- 2026-10-09：ユーザー指定のsgt9863.comへ公開するため、既存GitHub Pagesリポジトリのmainへコミット`b65913a`をpush。配置先は`/python-data-learning/`、トップに案内カードを追加。GitHub Pagesのbuild/deployment成功と公開HTTP200、トップの案内リンクを確認。

- 公開URLでブラウザの全操作テストを再実行し成功。Obsidian SHIMPEIのInboxへ要約・参照先を保存し、読み戻し確認済み。ローカル起動済み：サイト5186、JupyterLab8891。

## 2026-10-09 — Domain design alignment

Added a domain-home footer link and increased copy-button height to 44px to match the domain-wide DADS-inspired design. Curriculum and notebooks are unchanged. Repackage and export from this source; do not edit the published copy alone.

User follow-up: Python now uses teal #006b5e, matching pale surfaces; white contrast6.43. Travel is excluded from the domain design.
