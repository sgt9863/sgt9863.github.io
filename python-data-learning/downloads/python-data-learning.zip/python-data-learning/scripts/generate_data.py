"""Create fictional educational observations; no real measurements are used."""
from pathlib import Path
import numpy as np
import pandas as pd
ROOT = Path(__file__).resolve().parents[1]
rng = np.random.default_rng(42)
n = 360
kind = np.tile(np.arange(3), n // 3)
temp = rng.uniform(25, 45, n).round(1)
flow = rng.uniform(.5, 1., n).round(2)
acn = rng.uniform(25, 45, n).round(1)
instrument = rng.choice(['LC-A', 'LC-B'], n)
retention = (12 + kind * 2 - .12 * (temp-35) - .2 * (acn-35)) * .7 / flow + rng.normal(0,.35,n)
resolution = 1.65 - .003 * (temp-34)**2 - .025*(acn-34) - .45*(flow-.7) + kind*.08 + rng.normal(0,.16,n)
content = np.maximum(.1, rng.normal(np.choose(kind, [8, 12, 16]), 1.8, n))
frame = pd.DataFrame({'sample_id': [f'S{i+1:04d}' for i in range(n)], 'herb':np.choose(kind,['ショウキョウ','カンゾウ','オウゴン']), 'analyte':np.choose(kind,['6-gingerol','グリチルリチン','バイカリン']), 'instrument':instrument, 'temperature':temp,'flow':flow,'acn':acn,'peak_area':(content*10000+rng.normal(0,1200,n)).round(0),'content_mg_g':content.round(3),'retention_min':retention.round(3),'resolution':resolution.clip(.2).round(3)})
frame.loc[rng.choice(np.arange(5,n),18,replace=False),'temperature'] = np.nan
frame.loc[rng.choice(np.arange(5,n),24,replace=False),'content_mg_g'] = np.nan
(ROOT/'data').mkdir(exist_ok=True)
frame.to_csv(ROOT/'data/hplc.csv',index=False)
pd.DataFrame({'analyte':['6-gingerol','グリチルリチン','バイカリン'], 'class':['ジンゲロール類','サポニン類','フラボノイド類'], 'detection_nm':[280,254,280]}).to_csv(ROOT/'data/analytes.csv',index=False)
print(frame.shape, 'class counts', (frame.resolution>=1.5).value_counts().to_dict())
