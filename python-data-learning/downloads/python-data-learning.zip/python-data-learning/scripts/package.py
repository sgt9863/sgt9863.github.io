from pathlib import Path
import zipfile
ROOT=Path(__file__).resolve().parents[1]
allowed=['site','content','data','assets','scripts','tests']
files=[ROOT/x for x in ['README.md','requirements.txt','requirements-lock.txt','requirements-dev.txt','learning.py','serve.py','exercises.ipynb','solutions.ipynb','DEVELOPMENT.md','VALIDATION.md'] if (ROOT/x).exists()]
files += [p for d in allowed for p in (ROOT/d).rglob('*') if p.is_file() and '__pycache__' not in p.parts and '.DS_Store'!=p.name]
(ROOT/'downloads').mkdir(exist_ok=True)
with zipfile.ZipFile(ROOT/'downloads/python-data-learning.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(files):z.write(p,Path('python-data-learning')/p.relative_to(ROOT))
print('Packaged', len(files), 'files')
