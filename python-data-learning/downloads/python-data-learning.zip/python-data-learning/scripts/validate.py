"""Content parity, fresh-chapter execution, and answer-check behavior."""
from pathlib import Path
import json, sys, copy, tempfile, contextlib, io
import nbformat
from nbclient import NotebookClient
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))

def execute(nb, path):
    return NotebookClient(copy.deepcopy(nb),timeout=180,kernel_name='python3',resources={'metadata':{'path':str(path)}}).execute()

def main():
    course=json.loads((ROOT/'content/course.json').read_text())
    lessons=[l for c in course['chapters'] for l in c['lessons']]
    ids=[l['id'] for l in lessons]
    payload=json.loads((ROOT/'site/course.js').read_text().removeprefix('window.COURSE = ').removesuffix(';\n'))
    assert [l['id'] for c in payload['chapters'] for l in c['lessons']]==ids
    assert [c['title'] for c in payload['chapters']]==[c['title'] for c in course['chapters']]
    assert len(ids)==len(set(ids))
    assert [l['id'] for c in course['chapters'] if c['title']=='pandas' for l in c['lessons']]==[f'PD-{i:02d}' for i in range(1,27)]
    for source,display in zip(lessons,[l for c in payload['chapters'] for l in c['lessons']]):
        assert source['exercise']['prompt']==display['exercise']['prompt']
        assert source['example']==display['example']
        assert display['output_html']
        assert 20<=source['minutes']<=40
        assert all(source[k] for k in ['goals','explanation','example','reading','mistakes','reflection'])
        if source['id'].startswith('PD-'):
            assert all(source.get(k) for k in ['unit','apis','scenario','try_it','references'])
            for key in ['scenario','apis','try_it','references']:
                assert source[key]==display[key]
    for c in course['chapters'][1:6]:assert len(c['lessons'])>=3
    notebooks={kind:nbformat.read(ROOT/f'{kind}.ipynb',as_version=4) for kind in ['exercises','solutions']}
    assert sorted(p.name for p in ROOT.glob('*.ipynb'))==['exercises.ipynb','solutions.ipynb']
    for kind,nb in notebooks.items():
        nbformat.validate(nb)
        assert nb.metadata.kernelspec.name=='python3'
        assert [c.metadata.lesson for c in nb.cells if c.metadata.get('kind')=='check']==ids
        assert [c.metadata.chapter for c in nb.cells if c.metadata.get('kind')=='setup']==[c['title'] for c in course['chapters']]
        markdown='\n'.join(c.source for c in nb.cells if c.cell_type=='markdown')
        for lesson in lessons:assert lesson['exercise']['prompt'] in markdown
        for lesson in lessons:
            if lesson['id'].startswith('PD-'):
                assert lesson['scenario'] in markdown
                assert all(task in markdown for task in lesson['try_it'])
        if kind=='exercises':
            assert not any(c.metadata.get('kind')=='solution' for c in nb.cells)
            assert all(not c.outputs and c.execution_count is None for c in nb.cells if c.cell_type=='code')
            for lesson in lessons:
                starter=next(c.source for c in nb.cells if c.metadata.get('kind')=='starter' and c.metadata.lesson==lesson['id'])
                assert 'TODO' in starter and lesson['exercise']['variable']+' = None' in starter
        else:
            assert all(c.execution_count is not None for c in nb.cells if c.cell_type=='code')
            assert not any(o.output_type=='error' for c in nb.cells if c.cell_type=='code' for o in c.outputs)
        # Every chapter is run in a NEW kernel, including chapters reached after unanswered work.
        starts=[i for i,c in enumerate(nb.cells) if c.metadata.get('kind')=='setup']+[len(nb.cells)]
        for i,(start,end) in enumerate(zip(starts,starts[1:])):
            part=nbformat.v4.new_notebook(cells=copy.deepcopy(nb.cells[start:end]),metadata=nb.metadata)
            ran=execute(part,ROOT)
            checks=[c for c in ran.cells if c.metadata.get('kind')=='check']
            expected='まだ未回答' if kind=='exercises' else '自動確認の条件を満たしました'
            for c in checks:assert expected in ''.join(o.get('text','') for o in c.outputs), (kind,c.metadata.lesson)
            print(f'PASS fresh chapter {kind}: {course["chapters"][i]["title"]}',flush=True)
    # Fresh namespaces prove each pandas lesson needs only the chapter setup.
    # Use a real notebook kernel so plots use the same inline backend as JupyterLab.
    pandas_chapter=next(c for c in course['chapters'] if c['title']=='pandas')
    isolated=[nbformat.v4.new_code_cell('''import pandas as pd
def changed_value(value):
    return value + '__changed' if isinstance(value, str) else value + 1
def corrupted_answer(answer):
    if isinstance(answer, dict):
        result = answer.copy()
        first = next(iter(result))
        result[first] = corrupted_answer(result[first])
        return result
    if isinstance(answer, pd.DataFrame):
        result = answer.copy(deep=True)
        result.iloc[0, 0] = changed_value(result.iloc[0, 0])
        return result
    if isinstance(answer, pd.Series):
        result = answer.copy(deep=True)
        replacement = changed_value(result.iloc[0])
        if isinstance(result.dtype, pd.CategoricalDtype):
            result = result.cat.add_categories([replacement])
        result.iloc[0] = replacement
        return result
    return changed_value(answer)
''')]
    for lesson in pandas_chapter['lessons']:
        ex=lesson['exercise']
        for part,source in [('example',lesson['example']),('solution',ex['solution'])]:
            script=f"scope = {{}}\nexec({pandas_chapter['setup']!r}, scope)\noriginal = scope['df'].copy(deep=True)\nexec({source!r}, scope)\nscope['pd'].testing.assert_frame_equal(original, scope['df'])\n"
            if part=='solution':
                script+=f"assert scope['check_answer']({lesson['id']!r}, scope[{ex['variable']!r}])\n"
                script+=f"assert not scope['check_answer']({lesson['id']!r}, corrupted_answer(scope[{ex['variable']!r}]))\n"
            isolated.append(nbformat.v4.new_code_cell(script))
    execute(nbformat.v4.new_notebook(cells=isolated,metadata=notebooks['solutions'].metadata),ROOT)
    print('PASS all 26 pandas lessons with independent preparation and unchanged input',flush=True)
    from learning import check_answer
    for lesson in lessons:
        with contextlib.redirect_stdout(io.StringIO()) as output:
            assert check_answer(lesson['id'],None) is False
        assert '未回答' in output.getvalue()
        with contextlib.redirect_stdout(io.StringIO()):
            assert check_answer(lesson['id'],object()) is False
    with contextlib.redirect_stdout(io.StringIO()):
        assert check_answer('ML-03',{'mae':0.1,'baseline_mae':1.0,'r2':0.9}) is False
    # Check cells also guide users who have not yet run their TODO cell.
    for lesson in lessons:
        check=next(c for c in notebooks['exercises'].cells if c.metadata.get('kind')=='check' and c.metadata.lesson==lesson['id'])
        with contextlib.redirect_stdout(io.StringIO()) as output:
            exec(check.source,{})
        assert '未回答' in output.getvalue()
    print(f'PASS content parity, {len(ids)} empty answers and {len(ids)} wrong-type answers',flush=True)
    print('ALL NOTEBOOK VALIDATIONS PASSED',flush=True)
if __name__=='__main__':main()
