"""Content parity, fresh-chapter execution, and answer-check behavior."""
from pathlib import Path
import json, sys, copy, tempfile, contextlib, io
import nbformat
from nbclient import NotebookClient
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))

def execute(nb, path):
    return NotebookClient(copy.deepcopy(nb),timeout=180,kernel_name='python3',resources={'metadata':{'path':str(path)}}).execute()

def main():
    course=json.loads((ROOT/'content/course.json').read_text())
    lessons=[l for c in course['chapters'] for l in c['lessons']]
    ids=[l['id'] for l in lessons]
    payload=json.loads((ROOT/'site/course.js').read_text().removeprefix('window.COURSE = ').removesuffix(';\n'))
    assert [l['id'] for c in payload['chapters'] for l in c['lessons']]==ids
    assert [c['title'] for c in payload['chapters']]==[c['title'] for c in course['chapters']]
    assert len(ids)==len(set(ids))
    assert [l['id'] for c in course['chapters'] if c['title']=='pandas' for l in c['lessons']]==[f'PD-{i:02d}' for i in range(1,27)]
    assert [l['id'] for c in course['chapters'] if c['title']=='NumPy' for l in c['lessons']]==[f'NP-{i:02d}' for i in range(1,25)]
    assert [l['id'] for c in course['chapters'] if c['title']=='Matplotlib' for l in c['lessons']]==[f'MPL-{i:02d}' for i in range(1,27)]
    assert [l['id'] for c in course['chapters'] if c['title']=='scikit-learn' for l in c['lessons']]==[f'ML-{i:02d}' for i in range(1,33)]
    for source,display in zip(lessons,[l for c in payload['chapters'] for l in c['lessons']]):
        assert source['exercise']['prompt']==display['exercise']['prompt']
        assert source['example']==display['example']
        assert display['output_html']
        assert 20<=source['minutes']<=40
        assert all(source[k] for k in ['goals','explanation','example','reading','mistakes','reflection'])
        if source['id'].startswith(('PD-', 'NP-', 'MPL-', 'SNS-', 'ML-')):
            assert all(source.get(k) for k in ['unit','apis','scenario','try_it','references'])
            for key in ['scenario','apis','try_it','references']:
                assert source[key]==display[key]
    for c in course['chapters'][1:6]:assert len(c['lessons'])>=3
    notebooks={kind:nbformat.read(ROOT/f'{kind}.ipynb',as_version=4) for kind in ['exercises','solutions']}
    assert sorted(p.name for p in ROOT.glob('*.ipynb'))==['exercises.ipynb','solutions.ipynb']
    for kind,nb in notebooks.items():
        nbformat.validate(nb)
        assert nb.metadata.kernelspec.name=='python3'
        assert [c.metadata.lesson for c in nb.cells if c.metadata.get('kind')=='check']==ids
        assert [c.metadata.chapter for c in nb.cells if c.metadata.get('kind')=='setup']==[c['title'] for c in course['chapters']]
        markdown='\n'.join(c.source for c in nb.cells if c.cell_type=='markdown')
        for lesson in lessons:assert lesson['exercise']['prompt'] in markdown
        for lesson in lessons:
            if lesson['id'].startswith(('PD-', 'NP-', 'MPL-', 'SNS-', 'ML-')):
                assert lesson['scenario'] in markdown
                assert all(task in markdown for task in lesson['try_it'])
        if kind=='exercises':
            assert not any(c.metadata.get('kind')=='solution' for c in nb.cells)
            assert all(not c.outputs and c.execution_count is None for c in nb.cells if c.cell_type=='code')
            for lesson in lessons:
                starter=next(c.source for c in nb.cells if c.metadata.get('kind')=='starter' and c.metadata.lesson==lesson['id'])
                assert 'TODO' in starter and lesson['exercise']['variable']+' = None' in starter
        else:
            assert all(c.execution_count is not None for c in nb.cells if c.cell_type=='code')
            assert not any(o.output_type=='error' for c in nb.cells if c.cell_type=='code' for o in c.outputs)
        # Every chapter is run in a NEW kernel, including chapters reached after unanswered work.
        starts=[i for i,c in enumerate(nb.cells) if c.metadata.get('kind')=='setup']+[len(nb.cells)]
        for i,(start,end) in enumerate(zip(starts,starts[1:])):
            part=nbformat.v4.new_notebook(cells=copy.deepcopy(nb.cells[start:end]),metadata=nb.metadata)
            ran=execute(part,ROOT)
            checks=[c for c in ran.cells if c.metadata.get('kind')=='check']
            expected='まだ未回答' if kind=='exercises' else '自動確認の条件を満たしました'
            for c in checks:assert expected in ''.join(o.get('text','') for o in c.outputs), (kind,c.metadata.lesson)
            print(f'PASS fresh chapter {kind}: {course["chapters"][i]["title"]}',flush=True)
    # Fresh namespaces prove expanded lessons need only their chapter setup.
    # Use a real notebook kernel so plots use the same inline backend as JupyterLab.
    expanded_chapters=[c for c in course['chapters'] if c['title'] in ('pandas','NumPy','Matplotlib','seaborn','scikit-learn')]
    isolated=[nbformat.v4.new_code_cell('''import pandas as pd
import numpy as np
import copy
from matplotlib.figure import Figure
def changed_value(value):
    if isinstance(value, (float, np.floating)) and not np.isfinite(value):
        return 0.0
    return value + '__changed' if isinstance(value, str) else value + 1
def corrupted_answer(answer):
    if hasattr(answer, 'named_steps'):
        result = copy.deepcopy(answer)
        result.named_steps['predict'].coef_.flat[0] += 1
        return result
    if isinstance(answer, Figure):
        result = copy.deepcopy(answer)
        for ax in result.axes:
            ax.set_xlabel(ax.get_xlabel() + '__changed')
            ax.set_ylabel(ax.get_ylabel() + '__changed')
            for label in ax.texts:
                label.set_text(label.get_text() + '__changed')
            for line in ax.lines:
                line.set_ydata(np.asarray(line.get_ydata(), dtype=float) + 1)
            for patch in ax.patches:
                if hasattr(patch, 'set_height'):
                    patch.set_height(patch.get_height() + 1)
                    patch.set_width(patch.get_width() + 1)
                elif hasattr(patch, 'theta1'):
                    patch.set_theta1(patch.theta1 + 10)
                    patch.set_theta2(patch.theta2 + 20)
            for collection in ax.collections:
                if hasattr(collection, 'levels'):
                    collection.levels = np.asarray(collection.levels) + 1
                if hasattr(collection, '_offsets3d'):
                    collection._offsets3d = tuple(np.asarray(v) + 1 for v in collection._offsets3d)
                elif collection.get_offsets().size:
                    collection.set_offsets(collection.get_offsets() + 1)
                values = collection.get_array()
                if values is not None:
                    collection.set_array(values + 1)
                if hasattr(collection, 'get_segments'):
                    collection.set_segments([np.asarray(segment) + 1 for segment in collection.get_segments()])
            for im in ax.images:
                im.set_data(im.get_array() + 1)
        return result
    if isinstance(answer, np.ndarray):
        result = answer.copy()
        if result.dtype.kind == 'b':
            result.flat[0] = not result.flat[0]
        else:
            finite = np.flatnonzero(np.isfinite(result))
            result.flat[finite[0] if len(finite) else 0] += 1
        return result
    if isinstance(answer, (list, tuple)):
        result = list(answer)
        result[0] = corrupted_answer(result[0])
        return type(answer)(result)
    if isinstance(answer, dict):
        result = answer.copy()
        first = next(iter(result))
        result[first] = corrupted_answer(result[first])
        return result
    if isinstance(answer, pd.DataFrame):
        result = answer.copy(deep=True)
        result.iloc[0, 0] = changed_value(result.iloc[0, 0])
        return result
    if isinstance(answer, pd.Series):
        result = answer.copy(deep=True)
        replacement = changed_value(result.iloc[0])
        if isinstance(result.dtype, pd.CategoricalDtype):
            result = result.cat.add_categories([replacement])
        result.iloc[0] = replacement
        return result
    return changed_value(answer)
''')]
    for chapter in expanded_chapters:
        for lesson in chapter['lessons']:
            if chapter['title']=='seaborn' and lesson['id'] in ('SNS-01','SNS-02','SNS-03'):
                continue  # legacy introductory checks predate the corruption-sensitive grading contract
            ex=lesson['exercise']
            for part,source in [('example',lesson['example']),('solution',ex['solution'])]:
                script=f"scope = {{}}\nexec({chapter['setup']!r}, scope)\noriginal = scope['df'].copy(deep=True)\nexec({source!r}, scope)\nscope['pd'].testing.assert_frame_equal(original, scope['df'])\n"
                if part=='solution':
                    script+=f"assert scope['check_answer']({lesson['id']!r}, scope[{ex['variable']!r}])\n"
                    script+=f"assert not scope['check_answer']({lesson['id']!r}, corrupted_answer(scope[{ex['variable']!r}]))\n"
                isolated.append(nbformat.v4.new_code_cell(script))
    execute(nbformat.v4.new_notebook(cells=isolated,metadata=notebooks['solutions'].metadata),ROOT)
    print('PASS expanded pandas/NumPy/Matplotlib/seaborn/scikit-learn lessons: independent preparation, unchanged input, correct and corrupted answers',flush=True)
    from learning import check_answer
    for lesson in lessons:
        with contextlib.redirect_stdout(io.StringIO()) as output:
            assert check_answer(lesson['id'],None) is False
        assert '未回答' in output.getvalue()
        with contextlib.redirect_stdout(io.StringIO()):
            assert check_answer(lesson['id'],object()) is False
    with contextlib.redirect_stdout(io.StringIO()):
        assert check_answer('ML-03',{'mae':0.1,'baseline_mae':1.0,'r2':0.9}) is False
    # Check cells also guide users who have not yet run their TODO cell.
    for lesson in lessons:
        check=next(c for c in notebooks['exercises'].cells if c.metadata.get('kind')=='check' and c.metadata.lesson==lesson['id'])
        with contextlib.redirect_stdout(io.StringIO()) as output:
            exec(check.source,{})
        assert '未回答' in output.getvalue()
    print(f'PASS content parity, {len(ids)} empty answers and {len(ids)} wrong-type answers',flush=True)
    print('ALL NOTEBOOK VALIDATIONS PASSED',flush=True)
if __name__=='__main__':main()
