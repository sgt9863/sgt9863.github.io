"""Content parity, fresh-chapter execution, and answer-check behavior."""
from pathlib import Path
import json, sys, copy, tempfile, contextlib, io
import nbformat
from nbclient import NotebookClient
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))

def execute(nb, path):
    return NotebookClient(copy.deepcopy(nb),timeout=180,kernel_name='python3',resources={'metadata':{'path':str(path)}}).execute()

def main():
    course=json.loads((ROOT/'content/course.json').read_text())
    lessons=[l for c in course['chapters'] for l in c['lessons']]
    ids=[l['id'] for l in lessons]
    payload=json.loads((ROOT/'site/course.js').read_text().removeprefix('window.COURSE = ').removesuffix(';\n'))
    assert [l['id'] for c in payload['chapters'] for l in c['lessons']]==ids
    assert [c['title'] for c in payload['chapters']]==[c['title'] for c in course['chapters']]
    assert len(ids)==24 and len(set(ids))==24
    for source,display in zip(lessons,[l for c in payload['chapters'] for l in c['lessons']]):
        assert source['exercise']['prompt']==display['exercise']['prompt']
        assert source['example']==display['example']
        assert display['output_html']
        assert 20<=source['minutes']<=40
        assert all(source[k] for k in ['goals','explanation','example','reading','mistakes','reflection'])
    for c in course['chapters'][1:6]:assert len(c['lessons'])>=3
    notebooks={kind:nbformat.read(ROOT/f'{kind}.ipynb',as_version=4) for kind in ['exercises','solutions']}
    assert sorted(p.name for p in ROOT.glob('*.ipynb'))==['exercises.ipynb','solutions.ipynb']
    for kind,nb in notebooks.items():
        nbformat.validate(nb)
        assert nb.metadata.kernelspec.name=='python3'
        assert [c.metadata.lesson for c in nb.cells if c.metadata.get('kind')=='check']==ids
        assert [c.metadata.chapter for c in nb.cells if c.metadata.get('kind')=='setup']==[c['title'] for c in course['chapters']]
        markdown='\n'.join(c.source for c in nb.cells if c.cell_type=='markdown')
        for lesson in lessons:assert lesson['exercise']['prompt'] in markdown
        if kind=='exercises':
            assert not any(c.metadata.get('kind')=='solution' for c in nb.cells)
            assert all(not c.outputs and c.execution_count is None for c in nb.cells if c.cell_type=='code')
            for lesson in lessons:
                starter=next(c.source for c in nb.cells if c.metadata.get('kind')=='starter' and c.metadata.lesson==lesson['id'])
                assert 'TODO' in starter and lesson['exercise']['variable']+' = None' in starter
        else:
            assert all(c.execution_count is not None for c in nb.cells if c.cell_type=='code')
            assert not any(o.output_type=='error' for c in nb.cells if c.cell_type=='code' for o in c.outputs)
        # Every chapter is run in a NEW kernel, including chapters reached after unanswered work.
        starts=[i for i,c in enumerate(nb.cells) if c.metadata.get('kind')=='setup']+[len(nb.cells)]
        for i,(start,end) in enumerate(zip(starts,starts[1:])):
            part=nbformat.v4.new_notebook(cells=copy.deepcopy(nb.cells[start:end]),metadata=nb.metadata)
            ran=execute(part,ROOT)
            checks=[c for c in ran.cells if c.metadata.get('kind')=='check']
            expected='まだ未回答' if kind=='exercises' else '自動確認の条件を満たしました'
            for c in checks:assert expected in ''.join(o.get('text','') for o in c.outputs), (kind,c.metadata.lesson)
            print(f'PASS fresh chapter {kind}: {course["chapters"][i]["title"]}',flush=True)
    from learning import check_answer
    for lesson in lessons:
        with contextlib.redirect_stdout(io.StringIO()) as output:
            assert check_answer(lesson['id'],None) is False
        assert '未回答' in output.getvalue()
        with contextlib.redirect_stdout(io.StringIO()):
            assert check_answer(lesson['id'],object()) is False
    with contextlib.redirect_stdout(io.StringIO()):
        assert check_answer('ML-03',{'mae':0.1,'baseline_mae':1.0,'r2':0.9}) is False
    # Check cells also guide users who have not yet run their TODO cell.
    for lesson in lessons:
        check=next(c for c in notebooks['exercises'].cells if c.metadata.get('kind')=='check' and c.metadata.lesson==lesson['id'])
        with contextlib.redirect_stdout(io.StringIO()) as output:
            exec(check.source,{})
        assert '未回答' in output.getvalue()
    print('PASS content parity, 24 empty answers and 24 wrong-type answers',flush=True)
    print('ALL NOTEBOOK VALIDATIONS PASSED',flush=True)
if __name__=='__main__':main()
