"""Build both notebooks and static lesson payload from one authored course."""
from pathlib import Path
import sys, json, html, base64, copy, zipfile
import nbformat as nbf
from nbclient import NotebookClient
import markdown
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
META={'kernelspec':{'display_name':'Python 3 (ipykernel)','language':'python','name':'python3'},'language_info':{'name':'python','version':'3.12.13'}}
def md(s): return markdown.markdown(s, extensions=['tables','fenced_code'])
def text(s): return nbf.v4.new_markdown_cell(s)
def code(s, **tags): return nbf.v4.new_code_cell(s, metadata=tags)
def bullet(xs): return '\n'.join('- '+x for x in xs)
def exercise_text(l):
    e=l['exercise']
    data_note = e.get('data_note', 'この演習はCSVを使いません。' if l['id']=='PREP-01' else '`data/hplc.csv`（架空測定データ）、結合には `data/analytes.csv`。')
    return f"### 演習 {l['id']}\n\n{e['prompt']}\n\n使用データ：{data_note}この章の準備セルを先に実行します。ほかの演習への依存はありません。\n\n"+'\n\n'.join(f'<details><summary>ヒント{i+1}</summary>\n\n{hint}\n\n</details>' for i,hint in enumerate(e['hints']))
def execute(nb):
    return NotebookClient(nb,timeout=180,kernel_name='python3',resources={'metadata':{'path':str(ROOT)}}).execute()
def output_html(cell, lesson_id):
    out=[]
    for i,o in enumerate(cell.get('outputs',[])):
        if o.output_type=='error': raise RuntimeError(o)
        if o.output_type=='stream': out.append('<pre>'+html.escape(o.text)+'</pre>')
        elif 'data' in o:
            d=o.data
            if 'image/png' in d:
                name=f'{lesson_id}-{i}.png'; (ROOT/'site'/'images'/name).write_bytes(base64.b64decode(d['image/png']))
                out.append(f'<img src="images/{name}" alt="{lesson_id}の例題で描いたグラフ。読み取り方は直後の本文に説明しています。">')
            elif 'text/html' in d: out.append(d['text/html'])
            elif 'text/plain' in d: out.append('<pre>'+html.escape(d['text/plain'])+'</pre>')
    return '\n'.join(out)
def main():
    course=json.loads((ROOT/'content/course.json').read_text())
    assert len({l['id'] for c in course['chapters'] for l in c['lessons']})==sum(len(c['lessons']) for c in course['chapters'])
    (ROOT/'site/images').mkdir(exist_ok=True)
    notebooks={}
    for kind in ('exercises','solutions'):
        cells=[text('# 分析の手習い — '+('演習用' if kind=='exercises' else '解答確認用')+'\n\n架空のHPLC・生薬分析データで学ぶPython。サイトと同じ順序・演習IDです。各章の準備セルから始められます。初めての方はPREP-01から読みましょう。\n\n測定値は学習用の式で生成したものです。実際の分析法、成分の効能、規格適合を判断する教材ではありません。\n\n## 目次\n\n'+'\n'.join(f"- {c['title']}："+' / '.join(l['id'] for l in c['lessons']) for c in course['chapters']))]
        for ci,c in enumerate(course['chapters']):
            cells += [text(f"## {ci}. {c['title']}\n\nこの章の準備セルを最初に実行してください。前の章の回答は使いません。例題は実行して変更する見本、演習は自分で書く問題です。"),code(c['setup'],kind='setup',chapter=c['title'])]
            for l in c['lessons']:
                e=l['exercise']; lid=l['id']
                context = ('\n\n使う場面：'+l['scenario']) if l.get('scenario') else ''
                apis = ('\n\n扱う機能：'+', '.join('`'+a+'`' for a in l['apis'])) if l.get('apis') else ''
                practice = ('\n\n#### コードを変えて試す\n\n'+bullet(l['try_it'])) if l.get('try_it') else ''
                # The website uses h3 for explanation subsections. Inside a notebook lesson,
                # h4 keeps the chapter/lesson hierarchy and notebook TOC intact.
                explanation = l['explanation'].replace('### ', '#### ')
                cells += [text(f"### {lid}　{l['title']}\n\n目安：{l['minutes']}分 / 前提：{l['prerequisites']}{context}{apis}\n\n#### 学習目標\n\n{bullet(l['goals'])}\n\n{explanation}\n\n#### 例題（演習とは条件が異なります）"),code(l['example'],kind='example',lesson=lid),text(l['reading']+practice+'\n\n#### よくある間違い\n\n'+bullet(l['mistakes'])),text(exercise_text(l))]
                if kind=='solutions':
                    cells += [code(e['solution'],kind='solution',lesson=lid),text('#### 考え方と結果の読み取り\n\n'+e['reason'])]
                else:
                    cells += [code(e['starter'],kind='starter',lesson=lid)]
                cells += [code(f"from learning import check_answer\ncheck_answer('{lid}', globals().get('{e['variable']}'))",kind='check',lesson=lid),text('#### 自己確認と振り返り\n\n'+bullet(l['reflection'])+'\n\nグラフは軸・単位・比較対象・凡例、文章は根拠と限界を自分でも点検します。自動確認だけで解釈の正しさは判定できません。')]
                if l.get('references'):
                    cells += [text('#### 公式資料で調べる\n\n'+'\n'.join(f"- [{r['title']}]({r['url']})" for r in l['references']))]
        nb=nbf.v4.new_notebook(cells=cells,metadata=META)
        nbf.validate(nb)
        print(f'Execute {kind}: {len(cells)} cells',flush=True)
        executed=execute(copy.deepcopy(nb))
        errors=[o for cell in executed.cells if cell.cell_type=='code' for o in cell.outputs if o.output_type=='error']
        assert not errors
        warnings=[(cell.metadata.get('lesson',cell.metadata.get('chapter')),o.get('text','')) for cell in executed.cells if cell.cell_type=='code' for o in cell.outputs if o.get('name')=='stderr' and 'Warning' in o.get('text','')]
        assert not warnings, ('Unexpected notebook warning',warnings)
        if kind=='solutions':
            for cell in executed.cells:
                if cell.metadata.get('kind')=='check':
                    alltext=''.join(o.get('text','') for o in cell.outputs)
                    assert '自動確認の条件を満たしました' in alltext, (cell.metadata.get('lesson'),alltext)
            notebooks[kind]=executed
        else:
            # Execution is validated in memory; distributed exercise cells have no output.
            notebooks[kind]=nb
        nbf.write(notebooks[kind],ROOT/f'{kind}.ipynb')
    payload=copy.deepcopy(course)
    examples={cell.metadata['lesson']:cell for cell in notebooks['solutions'].cells if cell.metadata.get('kind')=='example'}
    for c in payload['chapters']:
        for l in c['lessons']:
            l['explanation_html']=md(l['explanation'])
            l['output_html']=output_html(examples[l['id']],l['id'])
            l['exercise']={k:l['exercise'][k] for k in ('prompt','hints','data_note') if k in l['exercise']}
    payload['pages']={p:md((ROOT/f'content/{p}.md').read_text()) for p in ('python','data')}
    (ROOT/'site/course.js').write_text('window.COURSE = '+json.dumps(payload,ensure_ascii=False)+';\n')
    # Subset the regular font to the characters actually used by the offline site.
    from fontTools import subset
    font = subset.load_font(str(ROOT/'assets/NotoSansJP.ttf'), subset.Options())
    subsetter = subset.Subsetter()
    web_text = ''.join(p.read_text() for p in (ROOT/'site').glob('*') if p.suffix in ('.js','.html','.css'))
    subsetter.populate(text=web_text+''.join(chr(i) for i in range(32,127)))
    subsetter.subset(font)
    font.save(str(ROOT/'assets/NotoSansJP-web.ttf'))
    print('Built site and exactly two notebooks.',flush=True)
if __name__=='__main__':main()
