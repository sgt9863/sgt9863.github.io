"""Export only browser assets and downloadable lessons to a static hosting folder."""
from pathlib import Path
import argparse, shutil
ROOT=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('destination',type=Path);args=p.parse_args()
out=args.destination.resolve();out.mkdir(parents=True,exist_ok=True)
for name in ['index.html','app.js','style.css','course.js']:
    text=(ROOT/'site'/name).read_text()
    if name=='app.js':text=text.replace('href="../','href="')
    if name=='style.css':text=text.replace("url('../assets/","url('assets/")
    (out/name).write_text(text)
for name,source in [('images',ROOT/'site/images'),('assets',ROOT/'assets'),('downloads',ROOT/'downloads')]:
    shutil.copytree(source,out/name,dirs_exist_ok=True)
for name in ['exercises.ipynb','solutions.ipynb']:shutil.copy2(ROOT/name,out/name)
print('Static export:',out)
