# 分析の手習い — HPLCデータで学ぶPython

架空のHPLC・生薬分析データで、pandas → NumPy → Matplotlib → seaborn → scikit-learn → 総合演習の順に学ぶローカル教材です。Pythonの基本文法を少し知っている方を想定しています。1レッスン20〜40分。最初に準備だけ済ませ、pandasでCSVを読む体験に進みます。

公開サイト：[分析の手習い](https://sgt9863.com/python-data-learning/)。公開サイトは解説と教材の配布を行い、コードは手元のJupyterLabで実行します。

## 最初に学ぶページと演習

1. サイトの「最小限の準備 / PREP-01」でセルの操作を確認します。
2. 「pandas / PD-01」で先頭5行、生薬の抽出、生薬別の平均成分量を確認します。
3. JupyterLabで `exercises.ipynb` を開き、pandas章の準備セルを実行します。
4. Notebook内検索（Cmd+F / Ctrl+F）で `PD-01` を探し、TODOセルを編集・実行します。
5. 自己確認セルを実行します。解いた後で `solutions.ipynb` の同じIDを開き、結果だけでなく理由も確認します。

例題と演習は条件を変えてあります。演習Notebookには解答コードや解答の実行出力を保存していません。各章の準備セルを実行すれば、前の章が未回答でも進められます。

## pandasの拡充版

[pandasの全体像・機能索引](https://sgt9863.com/python-data-learning/#pandas)から、機能名・API名・演習IDで探せます。全26レッスン、各20〜40分です。最初はPD-01〜05を順に進め、その後は前提知識を確かめながら、必要な機能を復習できます。

| 範囲 | 学ぶこと |
|---|---|
| PD-01〜05 | CSV、表の点検、抽出、列追加、欠損、集計、結合、ピボットと保存 |
| PD-06〜08 | 表とSeriesの作成、インデックス、複数条件、安全な更新、欠損対応の型 |
| PD-09〜12 | 文字列と正規表現、重複、カテゴリ、区間、日時・時差・経過時間 |
| PD-13〜16 | 複数キーの集計、transform、結合の検証、縦長・横長変換、MultiIndex |
| PD-17〜19 | 時間枠の集計、移動・累積平均、差・変化率、分布・相関・順位・抽出 |
| PD-20〜23 | 関数・map・apply・pipe、CSVの分割読込、Excel・JSON・SQLite・Parquet |
| PD-24〜26 | グラフ・表の表示、結果の検証、測定記録からの集計報告 |

pandas 2.3の[公式ユーザーガイド](https://pandas.pydata.org/pandas-docs/version/2.3/user_guide/index.html)を機能の対応表として使い、各ページにも該当する公式資料へのリンクを置きました。主要な表操作を学ぶ教材で、全APIのリファレンスではありません。HDF5・ORC・クラウドストレージ、拡張型の開発、Sparse、JIT最適化など、特定の環境や用途に限られる機能は対象外です。

各ページには、使う場面、学習目標、操作の理由、実行例と出力、条件を変える練習2つ、演習と段階的ヒント、つまずきと振り返りがあります。同じ内容を全章共通の2つのNotebookへ反映しています。既存のPD-01〜05の演習IDと達成条件を引き継いでいます。PD-05は文章の記入位置をTODOセル内のコメントとして具体化しました。

既に旧版を利用している場合は、自分の回答Notebookを別名で保存してから新版ZIPを展開し、`python -m pip install -r requirements.txt`を再実行してください。Excel用openpyxl 3.1.5とParquet用pyarrow 21.0.0が追加されました。教材実行中に追加ダウンロードは行いません。

## NumPyの拡充版

[NumPyの全体像・機能索引](https://sgt9863.com/python-data-learning/#numpy)から、API名・目的・演習IDで検索できます。全24レッスン、合計905分（約15時間）です。まずNP-01〜03で配列・axis・乱数を体験し、NP-04以降で操作を掘り下げます。各ページは30〜40分を目安にし、例題の条件を変える練習を2つずつ用意しました。

| 範囲 | 学ぶこと |
|---|---|
| NP-01〜03 | DataFrameと配列、形・型、単位換算、axis、乱数の入口 |
| NP-04〜10 | 配列作成、型と精度、変形、添字、ビューとコピー、結合・分割、全組み合わせ |
| NP-11〜15 | 数値関数と安全な除算、統計・欠損、累積、順位と検索、集合・整数コード集計、相関と度数 |
| NP-16〜17 | 抽出と分布、再現性、反復シミュレーション、ブートストラップ |
| NP-18〜21 | 行列と最小二乗、多項式、補間・微分・積分、FFTと周波数 |
| NP-22〜24 | npy・npz・テキスト保存、outとメモリマップ、測定条件の標準化と保存 |

NumPy 2.5の[基礎ガイド](https://numpy.org/doc/stable/user/basics.html)と[APIリファレンス](https://numpy.org/doc/stable/reference/index.html)を参照しました（確認2026-10-11）。主要な数値配列操作を実行して学ぶ範囲です。全APIの網羅ではなく、文字列・日時の本格処理はpandas章、高度なテンソル縮約・構造化配列・MaskedArray・ビット演算・独自dtype・C API・F2PY・GPU連携は対象外です。線形代数やFFTは小さな配列による入口とし、数学的な証明や実機の分析法検証までは扱いません。

同じHPLCの架空CSVを継続し、校正点・周期波・単純な波形は各セル内で作る合成値と明記しました。元CSVの行順を測定時系列として扱いません。列標準化の演習は記述的な整理であり、予測用の前処理では分割後の訓練データだけから統計量を求めます。

既存NP-01〜03の問題文・演習ID・達成条件を維持しました。NP-02の解答説明にあった抽出後の行数を360から120へ訂正しています。NumPy拡充時点では全66レッスンでした。Notebookは全章共通の2ファイルのままです。既存の回答を退避して新版ZIPを展開してください。NumPy拡充による追加依存はありません。

## Matplotlibの拡充版

Matplotlibを3から26レッスンへ拡充しました。各30〜40分、合計990分（16時間30分）です。まずMPL-01〜03で棒グラフ・散布図・複数の図の配置と保存を体験し、その後、目的に合う図の選び方と細かな調整を学びます。最初の3レッスンの演習IDと達成条件は引き継いでいます。

| 範囲 | 学ぶこと |
|---|---|
| MPL-01〜03 | FigureとAxes、基本の作図、複数の図と保存 |
| MPL-04〜10 | 折れ線・棒・散布図、分布、ばらつき、構成比 |
| MPL-11〜17 | 軸と目盛り、凡例、注釈、配置、色とヒートマップ |
| MPL-18〜20 | 等高線・矢印、日時軸、スタイルと日本語フォント |
| MPL-21〜24 | PNG・SVG・PDF保存、拡大図と副軸、極座標・3D、GIF |
| MPL-25〜26 | Artist（線や文字など図を構成する要素）の更新、作図関数、総合演習 |

[Matplotlibの全体像・機能索引](https://sgt9863.com/python-data-learning/#matplotlib)から、目的・API名・演習IDで探せます。教材全体は138レッスン・138演習となり、Notebookは全章共通の`exercises.ipynb`と`solutions.ipynb`の2ファイルを維持します。

引き続き架空のHPLC測定CSVを使います。日時・波形・曲面をセル内で作る例題には、合成値であることを明記しました。CSVの行順を実際の測定順とみなさず、図から分かることと分からないことを説明する練習も含みます。主要な作図機能を扱う範囲で、すべてのAPIや実機の分析法検証を網羅する教材ではありません。

[Matplotlib 3.10.8の公式資料](https://matplotlib.org/3.10.8/users/explain/quick_start.html)を参照しました（確認2026-10-11）。GUIへの組み込み、独自の描画要素や投影法の開発、イベント・ウィジェット、blitによる高速化、外部エンコーダーによる動画出力は対象外です。

Matplotlib 3.10.8を継続し、GIF保存に使うPillow 12.3.0を依存関係へ明記しました。初回セットアップ後の保存にネットワーク接続やffmpegの追加導入は不要です。GIFには静止図も添え、サイトでは自分で開くと再生し、閉じると停止できます。

旧版を更新する場合は、自分の回答Notebookを別名で保存してから新版ZIPを展開し、`python -m pip install -r requirements.txt`を再実行してください。

## seabornの拡充版

seabornを3から26レッスンへ広げました。所要時間は合計875分（約14時間35分）です。最初の3演習SNS-01〜03はIDを保ち、その後SNS-04〜26でaxes-levelとfigure-level、散布図・折れ線・分布図、カテゴリ比較、回帰診断、PairGrid・JointGrid・FacetGrid、相関ヒートマップ、配色とテーマまで学びます。最後のSNS-26では複数の図を組み合わせて結果と限界を短く説明します。

| 範囲 | 学ぶこと |
|---|---|
| SNS-01〜03 | DataFrameから分布、カテゴリ比較、散布図と相関を体験 |
| SNS-04〜10 | 縦長データ、軸単位とFigure単位の関数、散布図、折れ線、hist/KDE/ECDF |
| SNS-11〜17 | 点・箱・バイオリン、平均と誤差、件数、ファセット、回帰と残差 |
| SNS-18〜23 | JointGrid/PairGrid、heatmap/clustermap、FacetGrid、テーマと色 |
| SNS-24〜26 | 実験的なobjects API、統計要約の組み立て、複数図の報告 |

[snsの全体像・機能索引](https://sgt9863.com/python-data-learning/#seaborn)からAPI名・目的・演習IDで探せます。図の統計量と誤差区間、割合の分母、KDEの平滑化、欠損、相関と因果の違いを説明しています。架空データに時刻や反復測定がないため、日時のないCSVを時系列と呼ばず、回帰や群差から品質・薬効・原因を結論しません。

[seaborn 0.13.2公式チュートリアル](https://seaborn.pydata.org/tutorial.html)と[API一覧](https://seaborn.pydata.org/api.html)を参照しました（確認2026-10-12）。objects APIは公式資料が実験的・未完成な部分を含むと明記するため、SNS-24〜25で紹介に留め、関数形式APIも引き続き使います。教材は主要な作図機能を扱う範囲で、全APIを網羅するものではありません。

教材全体は138レッスン・138演習、Notebookは全章共通の`exercises.ipynb`と`solutions.ipynb`の2ファイルです。更新時は回答Notebookを別名で保存してから新版ZIPを展開してください。

## scikit-learnの拡充版

[scikit-learnの全体像・機能索引](https://sgt9863.com/python-data-learning/#scikit-learn)から、目的・API名・演習IDで探せます。全32レッスン、合計1,215分（20時間15分）を各30〜40分に分けました。まずML-01〜06で分割・前処理・回帰・分類・評価を一周し、その後に手法を掘り下げます。

| 範囲 | 学ぶこと |
|---|---|
| ML-01〜06 | 特徴量、目的変数、分割、Pipeline、ベースライン、過学習、交差検証 |
| ML-07〜09 | fit・transform・predict、複製と設定、欠損、尺度、カテゴリ、変換後の列名 |
| ML-10〜16 | 線形回帰と正則化、多項式、近傍法、SVM、決定木、ランダムフォレスト、ブースティング |
| ML-17〜24 | 回帰・分類指標、確率と閾値、分割戦略、探索、学習曲線、特徴選択、モデル解釈 |
| ML-25〜29 | PCA、KMeans、DBSCAN、階層型、外れ候補、NMF、混合正規分布 |
| ML-30〜32 | 目的変数変換、多出力とPLS、保存・再利用、比較から最終報告まで |

予測には測定前に分かる温度・流速・ACN比率・成分名・装置を使います。前処理は分割後の訓練データだけで学習し、特徴選択も含むPipelineを交差検証へ渡します。教師なし学習は測定後の記録を整理する別の用途として扱い、群や外れ候補を品質・薬効の判定に結び付けません。元CSVに日時・ロットはありません。

既存ML-01〜06の問題文とIDを維持し、全章共通のNotebook2ファイルへ反映しました。各レッスンは章の準備だけで実行でき、他の演習への回答には依存しません。同じCSVを繰り返す学習なので、教材の最終テストは評価手順の練習です。実際の予測性能を確認するには、モデル選択に使っていないデータが別途必要です。

[scikit-learn 1.7.2ユーザーガイド](https://scikit-learn.org/1.7/user_guide.html)と[前処理・漏洩の注意点](https://scikit-learn.org/1.7/common_pitfalls.html)を参照しました（確認2026-10-13）。表形式データを使った主要な機能群を学ぶ教材です。全推定器・全APIの解説ではなく、テキスト・画像の特徴抽出、半教師あり学習、ニューラルネットワーク、オンライン学習、ガウス過程、独自推定器の実装、大規模分散処理や実運用への配備は対象外です。

保存に使うjoblib 1.6.0をrequirements.txtへ明示しました。自分の回答Notebookを退避してから新版ZIPを展開し、依存ライブラリを再導入してください。モデルファイルは演習中に自分で作り、同じ環境で読み戻します。出所不明のjoblibファイルは読み込みません。

## 初回セットアップ

インターネット接続はPython・依存ライブラリの導入時だけ必要です。その後の教材実行に登録やダウンロードは不要です。Python 3.12を推奨します（この環境では3.12.13を使用）。

ZIPを使う場合は**すべて展開**し、ターミナルで展開した `python-data-learning` フォルダへ移動してください。Notebookだけを別フォルダに移すとCSVとフォントを読めません。

macOS / Linux:

```sh
python3.12 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
```

Python 3.12が `python3` という名前で入っている場合は最初のコマンドを `python3 -m venv .venv` に置き換えます。`uv`を利用している場合は `uv venv --python 3.12 .venv` と `uv pip install --python .venv/bin/python -r requirements.txt` でも構いません。

Windows PowerShell:

```powershell
py -3.12 -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt
```

## サイトとJupyterLabを起動する

このワークスペースの教材フォルダでは `.venv` を構築済みです。以下を別々のターミナルで、同じ教材フォルダから実行します。

サイト（Python標準ライブラリのみ）:

```sh
python3 serve.py
```

[学習サイトを開く](http://localhost:5186/site/)。ポートが使われている場合は `python3 serve.py --port 5187` とし、表示されたURLを開きます。

JupyterLab（macOS / Linux）:

```sh
source .venv/bin/activate
python -m jupyterlab
```

Windows:

```powershell
.venv\Scripts\python.exe -m jupyterlab
```

起動時にブラウザが開きます。開かない場合はターミナルに表示されたJupyterLabのURLを使います。左側のファイル一覧で `exercises.ipynb` をダブルクリックしてください。カーネルはPython 3を選びます。終了するときはターミナルでCtrl+Cを押します。

## セルの実行順と保存

セルを選び、Shift+Enterで実行します。保存はCmd+S / Ctrl+Sです。コードセルに表示される番号は、画面上の位置ではなく実行した順番です。値が予想と違ったら、Kernelメニューでカーネルを再起動し、章の準備セルから実行し直します。

再起動すると変数が消えます。解答全体の再現確認には「Restart Kernel and Run All Cells」を使います。演習の未回答セルは `None` のまま実行でき、自己確認セルが未回答と案内します。図や自由記述は自動確認の通過だけで正しさを決めず、振り返りの観点で確認してください。

## データ・フォント・出力

- `data/hplc.csv`：独立した架空の測定360件。1行は1検体の1成分です。実測や実ロットの反復ではありません。
- `data/analytes.csv`：成分名を結合キーにした3行の架空設定マスタ。
- 列の意味・単位・欠損数・用語は、サイトの「データと用語」と `content/data.md` にあります。
- `outputs/`：教材を実行すると作られるCSVや画像の保存先。入力のCSVは上書きしません。
- `assets/NotoSansJP.ttf`：日本語フォント（Regular 400に固定）を同梱。章の準備セルで `setup_plotting()` がMatplotlibへ登録します。seabornでテーマを変更したら、その後にも呼び直します。

Noto Sans JPはSIL Open Font License 1.1に基づき同梱しています。ライセンスは `assets/OFL.txt`、取得元は [Google Fontsの公式リポジトリ](https://github.com/google/fonts/tree/main/ofl/notosansjp) です。初期セットアップ後にフォントのダウンロードは行いません。サイト用の `NotoSansJP-web.ttf` は掲載文字だけを残した軽量版で、ビルド時に再生成します。

機械学習では測定前に分かる列だけを使い、分割後にPipelineの中で前処理を学習します。交差検証は訓練データ内で比較・選択するため、最終テストは決めたモデルの評価のために使います。架空の生成式を学ぶ練習なので、実試料の保持や品質を保証する結果ではありません。

## 技術構成と教材の更新

サイトはHTML/CSS/JavaScriptのみです。CDN、ログイン、データベース、サイト内Python実行はありません。学習状況はブラウザのlocalStorageへ保存します。ブラウザのデータ消去・別ブラウザ・別ポートには引き継がれません。

`content/course.json` が章・レッスン・演習の正本です。問題文と演習IDをここで変更し、ビルドするとサイトと2つのNotebookへ同じ内容を反映します。例題のサイト出力はNotebookで実行した結果から生成します。解答・採点式は教材のソースには含まれますが、サイトのレッスン本文には掲載しません。

```sh
source .venv/bin/activate
python scripts/build.py
python scripts/validate.py
python scripts/package.py
```

`build.py`は配布Notebookを上書きします。自分の回答を書き込んだNotebookは、編集・再ビルド前に別の場所へバックアップしてください。生成データを変更する必要がある場合に限り `python scripts/generate_data.py` を実行し、教材・出力・検証をすべて再生成します。

Notebookは `exercises.ipynb` と `solutions.ipynb` の2ファイルです。ビルド時の実行用コピーはメモリ上に作り、追加のNotebookを配布しません。ZIP内のサイトも起動できます。展開先でサイトを初めて起動すると、ダウンロード用ZIPがない場合は自動で作成します。展開先でZIPを再作成したい場合は `python scripts/package.py` を実行します（ZIPは自分自身を含みません）。

## デジタル庁デザインシステムから採用した考え方

確認日：2026-10-09。参照した公式資料はv2.18.0です。公式サイトや公式認定教材ではなく、指針を参考に作った独自教材です。

| 設計対象 | 参照ページ | 本教材への採用 |
|---|---|---|
| 色・フォーカス | [カラー](https://design.digital.go.jp/dads/foundations/color/) | 白地、濃色文字、青緑（#006b5e）の主要操作。黄色と黒の二重フォーカス。本文4.5:1以上を目標に確認 |
| 日本語の文字組み | [タイポグラフィ](https://design.digital.go.jp/dads/foundations/typography/) | Noto Sans JP、本文16px、行間1.9、見出し階層。コードは等幅 |
| 余白 | [余白](https://design.digital.go.jp/dads/foundations/spacing/) | 8pxを基準に関連する情報をまとめ、節間を広く取る |
| リンク | [リンクテキスト](https://design.digital.go.jp/dads/foundations/link-text/) | 本文リンクの下線、行き先が分かる文言、ダウンロード形式の明示 |
| ボタン | [ボタン](https://design.digital.go.jp/dads/components/button/) | 主操作と副操作を区別。移動はリンク、コピーはbutton。44px以上の主な操作領域 |
| ナビゲーション | [コンポーネント](https://design.digital.go.jp/dads/components/) | PCの左目次、スマートフォンの開閉目次、前後移動、現在位置の文字と線、本文へのスキップリンク |

完了は色だけで示さず「✓ 完了」と表示します。横幅の狭い画面では本文を1列にし、長いコードや表だけを横スクロールできます。

## バージョンと検証記録

主要ライブラリは `requirements.txt` で固定しています。pandas 2.3.3、NumPy 2.5.3、Matplotlib 3.10.8、seaborn 0.13.2、scikit-learn 1.7.2、JupyterLab 4.4.10を使用します。検証環境の全パッケージは `requirements-lock.txt` に記録しています（macOS固有の依存も含むので、別OSでは `requirements.txt` を使用）。

実施した検証と未確認事項は `VALIDATION.md`、設計の判断と変更経緯は `DEVELOPMENT.md` に記録します。

## 公開用の書き出し

`python scripts/export_site.py 公開先フォルダ`で静的ファイルと教材だけを書き出します。仮想環境や実行ログは公開しません。現在の公開先は `sgt9863.com/python-data-learning/`（既存のGitHub Pages）です。

ブラウザの回帰テストは開発者向けです。`requirements-dev.txt`を導入して `python tests/browser_test.py` を実行します。macOSのGoogle Chromeを使用し、学習サイトをポート5186で起動しておきます。通常の学習にPlaywrightは不要です。
