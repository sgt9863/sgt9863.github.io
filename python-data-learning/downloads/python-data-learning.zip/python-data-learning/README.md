# 分析の手習い — HPLCデータで学ぶPython

架空のHPLC・生薬分析データで、pandas → NumPy → Matplotlib → seaborn → scikit-learn → 総合演習の順に学ぶローカル教材です。Pythonの基本文法を少し知っている方を想定しています。1レッスン20〜40分。最初に準備だけ済ませ、pandasでCSVを読む体験に進みます。

公開サイト：[分析の手習い](https://sgt9863.com/python-data-learning/)。公開サイトは解説と教材の配布を行い、コードは手元のJupyterLabで実行します。

## 最初に学ぶページと演習

1. サイトの「最小限の準備 / PREP-01」でセルの操作を確認します。
2. 「pandas / PD-01」で先頭5行、生薬の抽出、生薬別の平均成分量を確認します。
3. JupyterLabで `exercises.ipynb` を開き、pandas章の準備セルを実行します。
4. Notebook内検索（Cmd+F / Ctrl+F）で `PD-01` を探し、TODOセルを編集・実行します。
5. 自己確認セルを実行します。解いた後で `solutions.ipynb` の同じIDを開き、結果だけでなく理由も確認します。

例題と演習は条件を変えてあります。演習Notebookには解答コードや解答の実行出力を保存していません。各章の準備セルを実行すれば、前の章が未回答でも進められます。

## 初回セットアップ

インターネット接続はPython・依存ライブラリの導入時だけ必要です。その後の教材実行に登録やダウンロードは不要です。Python 3.12を推奨します（この環境では3.12.13を使用）。

ZIPを使う場合は**すべて展開**し、ターミナルで展開した `python-data-learning` フォルダへ移動してください。Notebookだけを別フォルダに移すとCSVとフォントを読めません。

macOS / Linux:

```sh
python3.12 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
```

Python 3.12が `python3` という名前で入っている場合は最初のコマンドを `python3 -m venv .venv` に置き換えます。`uv`を利用している場合は `uv venv --python 3.12 .venv` と `uv pip install --python .venv/bin/python -r requirements.txt` でも構いません。

Windows PowerShell:

```powershell
py -3.12 -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt
```

## サイトとJupyterLabを起動する

このワークスペースの教材フォルダでは `.venv` を構築済みです。以下を別々のターミナルで、同じ教材フォルダから実行します。

サイト（Python標準ライブラリのみ）:

```sh
python3 serve.py
```

[学習サイトを開く](http://localhost:5186/site/)。ポートが使われている場合は `python3 serve.py --port 5187` とし、表示されたURLを開きます。

JupyterLab（macOS / Linux）:

```sh
source .venv/bin/activate
python -m jupyterlab
```

Windows:

```powershell
.venv\Scripts\python.exe -m jupyterlab
```

起動時にブラウザが開きます。開かない場合はターミナルに表示されたJupyterLabのURLを使います。左側のファイル一覧で `exercises.ipynb` をダブルクリックしてください。カーネルはPython 3を選びます。終了するときはターミナルでCtrl+Cを押します。

## セルの実行順と保存

セルを選び、Shift+Enterで実行します。保存はCmd+S / Ctrl+Sです。コードセルに表示される番号は、画面上の位置ではなく実行した順番です。値が予想と違ったら、Kernelメニューでカーネルを再起動し、章の準備セルから実行し直します。

再起動すると変数が消えます。解答全体の再現確認には「Restart Kernel and Run All Cells」を使います。演習の未回答セルは `None` のまま実行でき、自己確認セルが未回答と案内します。図や自由記述は自動確認の通過だけで正しさを決めず、振り返りの観点で確認してください。

## データ・フォント・出力

- `data/hplc.csv`：独立した架空の測定360件。1行は1検体の1成分です。実測や実ロットの反復ではありません。
- `data/analytes.csv`：成分名を結合キーにした3行の架空設定マスタ。
- 列の意味・単位・欠損数・用語は、サイトの「データと用語」と `content/data.md` にあります。
- `outputs/`：教材を実行すると作られるCSVや画像の保存先。入力のCSVは上書きしません。
- `assets/NotoSansJP.ttf`：日本語フォント（Regular 400に固定）を同梱。章の準備セルで `setup_plotting()` がMatplotlibへ登録します。seabornでテーマを変更したら、その後にも呼び直します。

Noto Sans JPはSIL Open Font License 1.1に基づき同梱しています。ライセンスは `assets/OFL.txt`、取得元は [Google Fontsの公式リポジトリ](https://github.com/google/fonts/tree/main/ofl/notosansjp) です。初期セットアップ後にフォントのダウンロードは行いません。サイト用の `NotoSansJP-web.ttf` は掲載文字だけを残した軽量版で、ビルド時に再生成します。

機械学習では測定前に分かる列だけを使い、分割後にPipelineの中で前処理を学習します。交差検証は訓練データ内で比較・選択するため、最終テストは決めたモデルの評価のために使います。架空の生成式を学ぶ練習なので、実試料の保持や品質を保証する結果ではありません。

## 技術構成と教材の更新

サイトはHTML/CSS/JavaScriptのみです。CDN、ログイン、データベース、サイト内Python実行はありません。学習状況はブラウザのlocalStorageへ保存します。ブラウザのデータ消去・別ブラウザ・別ポートには引き継がれません。

`content/course.json` が章・レッスン・演習の正本です。問題文と演習IDをここで変更し、ビルドするとサイトと2つのNotebookへ同じ内容を反映します。例題のサイト出力はNotebookで実行した結果から生成します。解答・採点式は教材のソースには含まれますが、サイトのレッスン本文には掲載しません。

```sh
source .venv/bin/activate
python scripts/build.py
python scripts/validate.py
python scripts/package.py
```

`build.py`は配布Notebookを上書きします。自分の回答を書き込んだNotebookは、編集・再ビルド前に別の場所へバックアップしてください。生成データを変更する必要がある場合に限り `python scripts/generate_data.py` を実行し、教材・出力・検証をすべて再生成します。

Notebookは `exercises.ipynb` と `solutions.ipynb` の2ファイルです。ビルド時の実行用コピーはメモリ上に作り、追加のNotebookを配布しません。ZIP内のサイトも起動できます。展開先でサイトを初めて起動すると、ダウンロード用ZIPがない場合は自動で作成します。展開先でZIPを再作成したい場合は `python scripts/package.py` を実行します（ZIPは自分自身を含みません）。

## デジタル庁デザインシステムから採用した考え方

確認日：2026-10-09。参照した公式資料はv2.18.0です。公式サイトや公式認定教材ではなく、指針を参考に作った独自教材です。

| 設計対象 | 参照ページ | 本教材への採用 |
|---|---|---|
| 色・フォーカス | [カラー](https://design.digital.go.jp/dads/foundations/color/) | 白地、濃色文字、青の主要操作。黄色と黒の二重フォーカス。本文4.5:1以上を目標に確認 |
| 日本語の文字組み | [タイポグラフィ](https://design.digital.go.jp/dads/foundations/typography/) | Noto Sans JP、本文16px、行間1.9、見出し階層。コードは等幅 |
| 余白 | [余白](https://design.digital.go.jp/dads/foundations/spacing/) | 8pxを基準に関連する情報をまとめ、節間を広く取る |
| リンク | [リンクテキスト](https://design.digital.go.jp/dads/foundations/link-text/) | 本文リンクの下線、行き先が分かる文言、ダウンロード形式の明示 |
| ボタン | [ボタン](https://design.digital.go.jp/dads/components/button/) | 主操作と副操作を区別。移動はリンク、コピーはbutton。44px以上の主な操作領域 |
| ナビゲーション | [コンポーネント](https://design.digital.go.jp/dads/components/) | PCの左目次、スマートフォンの開閉目次、前後移動、現在位置の文字と線、本文へのスキップリンク |

完了は色だけで示さず「✓ 完了」と表示します。横幅の狭い画面では本文を1列にし、長いコードや表だけを横スクロールできます。

## バージョンと検証記録

主要ライブラリは `requirements.txt` で固定しています。pandas 2.3.3、NumPy 2.5.3、Matplotlib 3.10.8、seaborn 0.13.2、scikit-learn 1.7.2、JupyterLab 4.4.10を使用します。検証環境の全パッケージは `requirements-lock.txt` に記録しています（macOS固有の依存も含むので、別OSでは `requirements.txt` を使用）。

実施した検証と未確認事項は `VALIDATION.md`、設計の判断と変更経緯は `DEVELOPMENT.md` に記録します。

## 公開用の書き出し

`python scripts/export_site.py 公開先フォルダ`で静的ファイルと教材だけを書き出します。仮想環境や実行ログは公開しません。現在の公開先は `sgt9863.com/python-data-learning/`（既存のGitHub Pages）です。

ブラウザの回帰テストは開発者向けです。`requirements-dev.txt`を導入して `python tests/browser_test.py` を実行します。macOSのGoogle Chromeを使用し、学習サイトをポート5186で起動しておきます。通常の学習にPlaywrightは不要です。
