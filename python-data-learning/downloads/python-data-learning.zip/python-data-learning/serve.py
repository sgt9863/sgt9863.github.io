"""Serve the local learning site without exposing the virtual environment."""
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote, urlsplit
import argparse
ROOT = Path(__file__).resolve().parent
class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)
    def do_GET(self):
        parts = Path(unquote(urlsplit(self.path).path)).parts
        if any(p.startswith('.') and p not in ('.', '..') for p in parts):
            self.send_error(404)
            return
        super().do_GET()
    def list_directory(self, path):
        self.send_error(404)
        return None
if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--port', type=int, default=5186)
    args = parser.parse_args()
    if not (ROOT/'downloads/python-data-learning.zip').exists():
        import runpy
        runpy.run_path(str(ROOT/'scripts/package.py'))
    print(f'学習サイト: http://localhost:{args.port}/site/', flush=True)
    ThreadingHTTPServer(('127.0.0.1', args.port), Handler).serve_forever()
